            <div class="foot-pay">
                <center>
                    <a href="#">Aide et Contact</a>
                    <a href="#">Confidentialité</a>
                    <a href="#">Légal</a>
                    <a href="#">Sécurité</a>                
                </center>            
            </div>